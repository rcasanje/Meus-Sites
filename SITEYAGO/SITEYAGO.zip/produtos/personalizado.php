<?php
	$pagina = $_GET['page'];
	
	printf('Página selecionada: %s', $pagina);
?>