<div class="container" id="rodape">
	<div class="row">
		<div class="col-xs-3">
			<p>Sobre</p>
		</div>
		<div class="col-xs-3">
			<p>Mapa do site</p>
			<ul type="none">
				<li><a href="administrador-acesso.php">Administrativo</a></li>
			</ul>
		</div>
		<div class="col-xs-3">
		</div>
		<div class="col-xs-3">
			<p>Redes sociais</p>
			<p>Facebook // Twitter</p>
		</div>
	</div>
</div>