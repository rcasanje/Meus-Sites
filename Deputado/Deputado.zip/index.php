<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8">
	<title>Gente ajudando gente</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</head>
<body style="background-image: url('images/logo.jpg'); background-repeat: no-repeat; background-size: 100% 100%">
	<header>
		<?php include("php/barra-de-menu.php"); ?>
	</header>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
			</div>
		</div>
		
	</div>
	<footer class="panel-footer">
		<?php include("php/rodape.php") ?>
	</footer>
</body>
</html>